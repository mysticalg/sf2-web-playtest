# Native special shortcuts

The native preview remains an incomplete part of the full AI Edition integration.

The optional checkbox enables mixed punch/kick chords. The per-player guide lists the available moves for the selected fighter and original/old style. Manual motions remain available. Shortcuts emit original controller inputs; they do not write move, damage, position, health or meter state. Supers require the original full meter. Throws still require native range and eligibility. Charge moves accumulate their normal charge time. Vega's flying grabs require a second chord in the air, near the opponent.

The two 720 supers use a neutral jump to buffer the native rotation. The adapter observes descent before sending the motion; it does not force a jump, grab or super state. Hit reactions interrupt pending input sequences, and a missed landing buffer expires instead of holding control indefinitely. Motion endings keep direction and button timing distinct where required by the original input parser.

Command provenance: the original [Capcom SSF2T manual](https://www.digitpress.com/library/manuals/3do/super_street_fighter_2_turbo.pdf), inspected as rendered pages, and activation in the native game. In particular, Spin Knuckle uses back/down-back/forward and Banishing Flat uses forward/down-forward/down. These motions were checked through native activation, rather than inferred from a successful ordinary attack.

Validation and native recovery evidence are included in reference-proof.json and qa/native-shortcuts-proof.json.
