// SPDX-License-Identifier: GPL-3.0-only
// Copyright (C) 2026 Tommy McLeroy. Part of cps2recomp.

#include "m68k.h"

#include "../runtime/native.h"
#include "../runtime/state.h"
#include "../video/native.h"

#include <bit>
#include <cstdio>
#include <cstdlib>
#include <map>
#include <tuple>
#include <algorithm>
#include <utility>

namespace cps2recomp {

namespace {
    int32_t Extend(uint32_t value, unsigned size) {
        return size == 0 ? static_cast<int8_t>(value) : size == 1 ? static_cast<int16_t>(value) : static_cast<int32_t>(value);
    }
    // What working out an operand's address and reading it costs: [long word][mode], mode 7 by register after
    constexpr uint8_t kOperandCycles[2][12] = {{0, 0, 4, 4, 6, 8, 10, 8, 12, 8, 10, 4}, {0, 0, 8, 8, 10, 12, 14, 12, 16, 12, 14, 8}};
    unsigned ModeIndex(unsigned mode, unsigned reg) {
        return mode < 7 ? mode : 7 + reg;
    }

    // CPS2RECOMP_VIDEO_CENSUS=FILE (docs/NATIVE_VIDEO.md): every instruction the interpreter runs that reads or
    // writes the video hardware (object memory, video RAM, the CPS-A and CPS-B registers, the object registers, the
    // object bank), with how often, the addresses it reached and the interrupt mask it ran under; written at exit
    struct VideoCensus {
        struct Entry {
            uint64_t count = 0;
            uint32_t low = 0xFFFFFFFF, high = 0;
            unsigned masks = 0;
        };
        FILE *out = nullptr;
        std::map<std::tuple<uint32_t, char, bool>, Entry> entries; // (instruction, region, written)
        VideoCensus() {
            if (const char *path = getenv("CPS2RECOMP_VIDEO_CENSUS")) {
                out = fopen(path, "w");
            }
        }
        ~VideoCensus() {
            if (!out) {
                return;
            }
            for (const auto &[key, e] : entries) {
                fprintf(out, "%06X %c %c %llu %06X-%06X mask%X\n", std::get<0>(key), std::get<1>(key), std::get<2>(key) ? 'W' : 'R',
                        static_cast<unsigned long long>(e.count), e.low, e.high, e.masks);
            }
            fclose(out);
        }
        static char Region(uint32_t address) {
            const uint32_t chip = address & ~0x4000u;
            if (address >= 0x700000 && address < 0x710000) return 'O'; // object memory
            if (address >= 0x900000 && address < 0x930000) return 'V'; // video RAM
            if (chip >= 0x800100 && chip < 0x800140) return 'A';       // CPS-A
            if (chip >= 0x800140 && chip < 0x800180) return 'B';       // CPS-B
            if (address >= 0x400000 && address < 0x40000C) return 'R'; // object registers
            if (address == 0x8040E0 || address == 0x8040E1) return 'K'; // object bank
            return 0;
        }
        void Note(uint32_t instruction, uint32_t address, bool written, unsigned mask) {
            const char region = Region(address & 0xFFFFFF);
            if (!region) {
                return;
            }
            Entry &e = entries[{instruction, region, written}];
            e.count++;
            e.low = std::min(e.low, address & 0xFFFFFF);
            e.high = std::max(e.high, address & 0xFFFFFF);
            e.masks |= 1u << mask;
        }
    };
    VideoCensus *Census() {
        static VideoCensus census;
        return census.out ? &census : nullptr;
    }
} // namespace

void M68K::Reset(bool hard) {
    if (hard) {
        for (int i = 0; i < 8; i++) {
            d[i] = a[i] = 0;
        }
        m_interruptLevel = 0;
    }
    a[7] = ReadProgram(0, 2); // (the reset vector is read as program)
    otherSP = 0;
    pc = ReadProgram(4, 2);
    flagC = flagV = flagZ = flagN = flagX = false;
    supervisor = true;
    trace = false;
    interruptMask = 7;
    stopped = false;
    depth = 0;
}

uint32_t M68K::Read(uint32_t address, unsigned size) {
    BusWait(address);
    if (size == 2) {
        BusWait(address + 2);
    }
#ifdef CPS2RECOMP_CHECK
    if (check::side) {
        return native::CheckRead(*this, address, size);
    }
#endif
    if (static VideoCensus *census = Census(); census) {
        census->Note(instruction, address, false, interruptMask);
    }
    switch (size) {
    case 0: return bus.Read8(address & 0xFFFFFF);
    case 1: return bus.Read16(address & 0xFFFFFE);
    default: {
        const uint32_t high = bus.Read16(address & 0xFFFFFE);
        return (high << 16) | bus.Read16((address + 2) & 0xFFFFFE);
    }
    }
}

void M68K::Write(uint32_t address, unsigned size, uint32_t value) {
    WriteWait(address);
    if (size == 2) {
        WriteWait(address + 2);
    }
    if (nativeWrites && nativeVideo && native_video::IsVideoRegister(address)) {
        // (a rewrite's: the game's side is told first, as a watch tells it before an instruction)
        if (size == 2) {
            nativeVideo->GameWrites(*this, address & 0xFFFFFF, static_cast<uint16_t>(value >> 16), false);
            nativeVideo->GameWrites(*this, (address + 2) & 0xFFFFFF, static_cast<uint16_t>(value), false);
        } else {
            nativeVideo->GameWrites(*this, address & 0xFFFFFF, static_cast<uint16_t>(value), size == 0);
        }
    }
#ifdef CPS2RECOMP_CHECK
    if (check::side) {
        native::CheckWrite(*this, address, size, value);
        return;
    }
    if (check::noting) {
        check::Note(address, size, value);
    }
#endif
    if (static VideoCensus *census = Census(); census) {
        census->Note(instruction, address, true, interruptMask);
    }
    if ((address & 0xFFFFFF) + kBytes[size] > watchLow && (address & 0xFFFFFF) <= watchHigh) {
        // (CPS2RECOMP_WATCH_REPORTS=N for more: the board's memory test alone can take the first 2,000)
        static int reports = getenv("CPS2RECOMP_WATCH_REPORTS") ? atoi(getenv("CPS2RECOMP_WATCH_REPORTS")) : 2000;
        if (reports > 0) {
            reports--;
            fprintf(stderr, "watch: %06X writes %0*X to %06X (cycle %llu)\n", instruction, static_cast<int>(kBytes[size] * 2),
                    value & kMask[size], address & 0xFFFFFF, static_cast<unsigned long long>(cycles));
        }
    }
    switch (size) {
    case 0: bus.Write8(address & 0xFFFFFF, static_cast<uint8_t>(value)); break;
    case 1: bus.Write16(address & 0xFFFFFE, static_cast<uint16_t>(value)); break;
    default:
        bus.Write16(address & 0xFFFFFE, static_cast<uint16_t>(value >> 16));
        bus.Write16((address + 2) & 0xFFFFFE, static_cast<uint16_t>(value));
        break;
    }
}

uint32_t M68K::ReadProgram(uint32_t address, unsigned size) {
    BusWait(address);
    if (size == 2) {
        BusWait(address + 2);
    }
    switch (size) {
    case 0: {
        const uint16_t word = bus.Fetch16(address & 0xFFFFFE);
        return (address & 1) ? (word & 0xFF) : (word >> 8);
    }
    case 1: return bus.Fetch16(address & 0xFFFFFE);
    default: {
        const uint32_t high = bus.Fetch16(address & 0xFFFFFE);
        return (high << 16) | bus.Fetch16((address + 2) & 0xFFFFFE);
    }
    }
}

uint16_t M68K::Fetch() {
    BusWait(pc); // (a word of the instruction)
    fetchedWords++;
    const uint16_t word = bus.Fetch16(pc & 0xFFFFFE);
    pc += 2;
    return word;
}

uint32_t M68K::Fetch32() {
    const uint32_t high = Fetch();
    return (high << 16) | Fetch();
}

void M68K::Push16(uint16_t value) {
    a[7] -= 2;
    Write(a[7], 1, value);
}

uint16_t M68K::Pop16() {
    const uint16_t value = static_cast<uint16_t>(Read(a[7], 1));
    a[7] += 2;
    return value;
}

void M68K::Exception(unsigned vector, uint32_t returnAddress, int level) {
    const uint16_t before = SR();
    if (!supervisor) {
        std::swap(a[7], otherSP);
        supervisor = true;
    }
    trace = false;
    if (level >= 0) {
        interruptMask = static_cast<uint8_t>(level);
    }
    Push32(returnAddress);
    Push16(before);
    pc = Read(vector * 4, 2);
    m_jumped = true;
}

bool M68K::TakeInterrupt() {
    if (m_interruptLevel == 7 || m_interruptLevel > interruptMask) {
        stopped = false;
        const uint8_t level = m_interruptLevel;
        Exception(24 + level, pc, level); // (the board asks for the autovector)
        bus.InterruptAck(level);
        // (with the board's bus waits: the acknowledge cycle, and the two words fetched at the handler)
        cycles += busWait * 3;
        waitsCounted += busWait * 3;
        return true;
    }
    return false;
}

void M68K::Serialize(Archive &ar) {
    // (a wait is kept as it is, so that keeping a state changes nothing: run-ahead keeps one every frame)
    ar.Mark(0x4D36384B);
    ar.Pod(d);
    ar.Pod(a);
    ar.Pod(otherSP);
    ar.Pod(pc);
    ar.Pod(flagC);
    ar.Pod(flagV);
    ar.Pod(flagZ);
    ar.Pod(flagN);
    ar.Pod(flagX);
    ar.Pod(supervisor);
    ar.Pod(trace);
    ar.Pod(interruptMask);
    ar.Pod(stopped);
    ar.Pod(m_interruptLevel);
    ar.Pod(cycles);
    ar.Pod(waitCycles);
    ar.Pod(waitResume);
    ar.Pod(waitStack);
    ar.Pod(waitClears);
    ar.Pod(waitArmed);
}
// GPL-3.0-only. Constant-site translations of the pinned arithmetic semantics.
void M68K::Interpret(uint32_t address) {
    // The generator calls this historical API name. No opcode fetch or decoder:
    // every admitted original EU site fixes its operation and registers.
    unsigned source=0,target=1,length=2,operandCycles=0;uint32_t immediate=0;bool signedDivide=false;
    switch(address){
    case 0x005aa4:break;
    case 0x090f78:case 0x09104c:case 0x0a3480:case 0x0a3554:case 0x0b3164:case 0x0b3248:source=3;target=1;signedDivide=true;break;
    case 0x090f94:case 0x091064:case 0x0a349c:case 0x0a356c:case 0x0b3180:case 0x0b3260:source=3;target=2;signedDivide=true;break;
    case 0x0a0850:immediate=20;length=4;operandCycles=4;target=0;signedDivide=true;break;
    case 0x09b396:source=4;target=3;break;
    case 0x096c7e:pc=address+2;BusWait(address);SetSR((SR()&0xff00)|(Read(a[0],1)&31));cycles+=16;return;
    default:fprintf(stderr,"Untranslated native instruction site %06X\n",address);abort();}
    pc=address+length;const uint32_t divisor=immediate?immediate:d[source]&65535;BusWait(address);if(length==4)BusWait(address+2);
    if(!divisor){Exception(5,pc,-1);flagN=flagZ=flagV=flagC=false;cycles+=42;cycles+=busWait;waitsCounted+=busWait;return;}
    flagZ=flagC=false;
    if(signedDivide){
        const int32_t dividend=static_cast<int32_t>(d[target]);const int16_t div=static_cast<int16_t>(divisor);
        const int64_t quotient=static_cast<int64_t>(dividend)/div,remainder=static_cast<int64_t>(dividend)%div;
        const uint32_t magnitude=static_cast<uint32_t>(dividend<0?-static_cast<int64_t>(dividend):dividend),limit=static_cast<uint32_t>(std::abs(static_cast<int32_t>(div)))<<16;
        if(magnitude>=limit&&div!=-0x8000){flagN=flagV=true;}else{flagZ=quotient==0;flagV=quotient!=static_cast<int16_t>(quotient);if(flagV)flagN=true;else{d[target]=static_cast<uint16_t>(quotient)|(static_cast<uint32_t>(static_cast<uint16_t>(remainder))<<16);flagN=quotient&0x8000;}}
        cycles+=158+operandCycles;
    }else{const uint32_t quotient=d[target]/divisor,remainder=d[target]%divisor;flagZ=quotient==0;flagV=quotient>65535;if(flagV)flagN=true;else{d[target]=quotient|(remainder<<16);flagN=quotient&0x8000;}cycles+=140;}
}

} // namespace cps2recomp
