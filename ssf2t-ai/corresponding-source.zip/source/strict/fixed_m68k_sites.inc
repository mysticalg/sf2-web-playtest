// GPL-3.0-only. Constant-site translations of the pinned arithmetic semantics.
void M68K::Interpret(uint32_t address) {
    // The generator calls this historical API name. No opcode fetch or decoder:
    // every admitted original EU site fixes its operation and registers.
    unsigned source=0,target=1,length=2,operandCycles=0;uint32_t immediate=0;bool signedDivide=false;
    switch(address){
    case 0x005aa4:break;
    case 0x090f78:case 0x09104c:case 0x0a3480:case 0x0a3554:case 0x0b3164:case 0x0b3248:source=3;target=1;signedDivide=true;break;
    case 0x090f94:case 0x091064:case 0x0a349c:case 0x0a356c:case 0x0b3180:case 0x0b3260:source=3;target=2;signedDivide=true;break;
    case 0x0a0850:immediate=20;length=4;operandCycles=4;target=0;signedDivide=true;break;
    case 0x09b396:source=4;target=3;break;
    case 0x096c7e:pc=address+2;BusWait(address);SetSR((SR()&0xff00)|(Read(a[0],1)&31));cycles+=16;return;
    default:fprintf(stderr,"Untranslated native instruction site %06X\n",address);abort();}
    pc=address+length;const uint32_t divisor=immediate?immediate:d[source]&65535;BusWait(address);if(length==4)BusWait(address+2);
    if(!divisor){Exception(5,pc,-1);flagN=flagZ=flagV=flagC=false;cycles+=42;cycles+=busWait;waitsCounted+=busWait;return;}
    flagZ=flagC=false;
    if(signedDivide){
        const int32_t dividend=static_cast<int32_t>(d[target]);const int16_t div=static_cast<int16_t>(divisor);
        const int64_t quotient=static_cast<int64_t>(dividend)/div,remainder=static_cast<int64_t>(dividend)%div;
        const uint32_t magnitude=static_cast<uint32_t>(dividend<0?-static_cast<int64_t>(dividend):dividend),limit=static_cast<uint32_t>(std::abs(static_cast<int32_t>(div)))<<16;
        if(magnitude>=limit&&div!=-0x8000){flagN=flagV=true;}else{flagZ=quotient==0;flagV=quotient!=static_cast<int16_t>(quotient);if(flagV)flagN=true;else{d[target]=static_cast<uint16_t>(quotient)|(static_cast<uint32_t>(static_cast<uint16_t>(remainder))<<16);flagN=quotient&0x8000;}}
        cycles+=158+operandCycles;
    }else{const uint32_t quotient=d[target]/divisor,remainder=d[target]%divisor;flagZ=quotient==0;flagV=quotient>65535;if(flagV)flagN=true;else{d[target]=quotient|(remainder<<16);flagN=quotient&0x8000;}cycles+=140;}
}
