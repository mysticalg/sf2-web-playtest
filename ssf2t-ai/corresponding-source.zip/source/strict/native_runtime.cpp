// GPL-3.0-only: adapted from the pinned cps2recomp native scheduling loop.
// No opcode fetch/Execute/interpretation path. All normal work dispatches static functions.
#include "native.h"
#include "native_z80.h"
#include <algorithm>
#include <cstdio>
#include <cstdlib>
namespace cps2recomp {
const uint8_t*g_watchMap=nullptr;uint32_t g_watchMapSize=0;void RunWatch(M68K&,uint32_t){}
namespace {[[noreturn]]void gap(const char*cpu,uint32_t pc){fprintf(stderr,"%s native translation missing at %06X\n",cpu,pc);abort();}
struct MainTable{std::vector<NativeFn>fn;MainTable(){uint32_t high=0;for(size_t n=0;n<kNativeCode.entryCount;n++)high=std::max(high,kNativeCode.entries[n].address);fn.resize(high/2+1);for(size_t n=0;n<kNativeCode.entryCount;n++)fn[kNativeCode.entries[n].address/2]=kNativeCode.entries[n].fn;}NativeFn at(uint32_t pc)const{return !(pc&1)&&pc/2<fn.size()?fn[pc/2]:nullptr;}};
struct SoundTable{Z80Fn fn[65536]={};SoundTable(){for(size_t n=0;n<kZ80Code.entryCount;n++)fn[kZ80Code.entries[n].address]=kZ80Code.entries[n].fn;}};
const MainTable&mainTable(){static MainTable t;return t;}const SoundTable&soundTable(){static SoundTable t;return t;}}
namespace native{void NotHere(M68K&c,uint32_t){gap("M68K block",c.pc);}}
namespace z80native{void NotHere(Z80&c,uint16_t){gap("Z80 block",c.pc);}}
bool HasNativeCode(){return kNativeCode.entryCount!=0;}bool HasZ80Code(){return kZ80Code.entryCount!=0;}
void M68K::Run(uint64_t until,Mode mode){if(mode!=Mode::Native)gap("Non-native mode",pc);budget=until;for(;;){if(TakeInterrupt())cycles+=44;if(waitArmed&&pc==waitResume&&a[7]==waitStack){uint64_t used=std::min(waitCycles,cycles<until?until-cycles:0);cycles+=used;waitCycles-=used;if(!waitCycles)FinishWait();}budget=until;if(cycles>=until)return;if(stopped){cycles=until;return;}NativeFn fn=mainTable().at(pc);if(!fn)gap("M68K",pc);depth=0;fn(*this);}}
void M68K::CallGuest(uint32_t address){constexpr uint32_t end=0xfedcba;uint64_t kept=budget;unsigned oldDepth=depth;budget=~uint64_t(0);Push32(end);pc=address;for(unsigned n=0;pc!=end;n++){if(n>50000000)gap("Native call timeout",pc);NativeFn fn=mainTable().at(pc);if(!fn)gap("M68K call",pc);depth=0;fn(*this);}budget=kept;depth=oldDepth;}
void M68K::RunToReturn(){gap("Offline-only reference requested",pc);}
void Z80::Run(uint64_t until,Mode modeIn){if(modeIn!=Mode::Native)gap("Non-native sound mode",pc);budget=until;for(;;){if(cycles>=until)return;
 if(m_afterEI){m_afterEI=false;refresh++;switch(pc){case 0x0074:pc=Pop();cycles+=10;break;case 0x007d:r[0]=4;pc=0x007f;cycles+=7;break;case 0x00e6:SetHL(0xf005);pc=0x00e9;cycles+=10;break;default:gap("Unadmitted native EI site",pc);}continue;}
 if(unsigned taken=TakeInterrupt()){cycles+=taken;continue;}if(halted){cycles=until;return;}Z80Fn fn=soundTable().fn[pc];if(!fn)gap("Z80",pc);depth=0;fn(*this);}}
} // namespace cps2recomp
