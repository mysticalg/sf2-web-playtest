// SPDX-License-Identifier: GPL-3.0-only
// Copyright (C) 2026 Tommy McLeroy. Part of cps2recomp.

#include "z80.h"
#include <cstdio>
#include <cstdlib>

#include "../runtime/native_z80.h"
#include "../runtime/state.h"

#include <utility>

namespace cps2recomp {

namespace {
    enum : uint8_t { kC = 0x01, kN = 0x02, kPV = 0x04, kX = 0x08, kH = 0x10, kY = 0x20, kZ = 0x40, kS = 0x80 };

    // Sign, zero, the two undocumented bits and parity of a byte
    struct FlagTable {
        uint8_t szp[256];
        constexpr FlagTable()
            : szp() {
            for (int v = 0; v < 256; v++) {
                int bits = 0;
                for (int b = 0; b < 8; b++) {
                    bits += (v >> b) & 1;
                }
                szp[v] = static_cast<uint8_t>((v & (kS | kX | kY)) | (v == 0 ? kZ : 0) | ((bits & 1) ? 0 : kPV));
            }
        }
    };
    constexpr FlagTable kFlags;


} // namespace

void Z80::Reset() {
    pc = 0;
    sp = 0xFFFF;
    i = refresh = 0;
    iff1 = iff2 = halted = false;
    mode = 0;
    m_interrupt = false;
    m_afterEI = false;
    depth = 0;
    for (auto &v : r) {
        v = 0xFF;
    }
    f = 0xFF;
}

uint8_t Z80::Rd(uint16_t address) {
#ifdef CPS2RECOMP_CHECK
    if (z80check::side) {
        return z80check::Read(*this, address);
    }
#endif
    return bus.Read(address);
}

void Z80::Wr(uint16_t address, uint8_t value) {
#ifdef CPS2RECOMP_CHECK
    if (z80check::side) {
        z80check::Write(*this, address, value);
        return;
    }
    if (z80check::noting) {
        z80check::Note(address, value);
    }
#endif
    bus.Write(address, value);
}

uint16_t Z80::Read16(uint16_t address) {
    const uint8_t low = Rd(address);
    return static_cast<uint16_t>(low | (Rd(static_cast<uint16_t>(address + 1)) << 8));
}

void Z80::Write16(uint16_t address, uint16_t value) {
    Wr(address, static_cast<uint8_t>(value));
    Wr(static_cast<uint16_t>(address + 1), static_cast<uint8_t>(value >> 8));
}

void Z80::Push(uint16_t value) {
    sp -= 2;
    Write16(sp, value);
}

uint16_t Z80::Pop() {
    const uint16_t value = Read16(sp);
    sp += 2;
    return value;
}

uint8_t Z80::Reg(unsigned n, unsigned prefix) const {
    if (prefix && n == 4) {
        return static_cast<uint8_t>((prefix == 1 ? ix : iy) >> 8);
    }
    if (prefix && n == 5) {
        return static_cast<uint8_t>(prefix == 1 ? ix : iy);
    }
    return r[n];
}

void Z80::SetReg(unsigned n, unsigned prefix, uint8_t v) {
    if (prefix && (n == 4 || n == 5)) {
        uint16_t &index = prefix == 1 ? ix : iy;
        index = n == 4 ? static_cast<uint16_t>((index & 0x00FF) | (v << 8)) : static_cast<uint16_t>((index & 0xFF00) | v);
        return;
    }
    r[n] = v;
}

uint16_t Z80::Pair(unsigned n, unsigned prefix) const {
    switch (n) {
    case 0: return BC();
    case 1: return DE();
    case 2: return Index(prefix);
    default: return sp;
    }
}

void Z80::SetPair(unsigned n, unsigned prefix, uint16_t v) {
    switch (n) {
    case 0: SetBC(v); break;
    case 1: SetDE(v); break;
    case 2: SetIndex(prefix, v); break;
    default: sp = v; break;
    }
}

bool Z80::Condition(unsigned cc) const {
    switch (cc) {
    case 0: return !(f & kZ);
    case 1: return f & kZ;
    case 2: return !(f & kC);
    case 3: return f & kC;
    case 4: return !(f & kPV);
    case 5: return f & kPV;
    case 6: return !(f & kS);
    default: return f & kS;
    }
}

void Z80::ExchangeAF() {
    std::swap(r[7], r2[7]);
    std::swap(f, f2);
}

void Z80::Exx() {
    for (int n = 0; n < 6; n++) {
        std::swap(r[n], r2[n]);
    }
}

void Z80::Alu(unsigned op, uint8_t value) {
    const uint8_t a = r[7];
    switch (op) {
    case 0:
    case 1: {
        const unsigned carry = (op == 1) ? (f & kC) : 0;
        const unsigned sum = a + value + carry;
        const uint8_t result = static_cast<uint8_t>(sum);
        f = static_cast<uint8_t>((result & (kS | kX | kY)) | (result == 0 ? kZ : 0) | ((a ^ value ^ result) & kH) |
                                 (((~(a ^ value) & (a ^ result)) & 0x80) ? kPV : 0) | (sum > 0xFF ? kC : 0));
        r[7] = result;
        break;
    }
    case 2:
    case 3:
    case 7: {
        const unsigned carry = (op == 3) ? (f & kC) : 0;
        const unsigned difference = a - value - carry;
        const uint8_t result = static_cast<uint8_t>(difference);
        f = static_cast<uint8_t>((result & kS) | (result == 0 ? kZ : 0) | ((a ^ value ^ result) & kH) |
                                 ((((a ^ value) & (a ^ result)) & 0x80) ? kPV : 0) | kN | (difference > 0xFF ? kC : 0));
        if (op == 7) {
            f |= value & (kX | kY); // (compare: the undocumented bits come from the operand)
        } else {
            f |= result & (kX | kY);
            r[7] = result;
        }
        break;
    }
    case 4:
        r[7] = a & value;
        f = kFlags.szp[r[7]] | kH;
        break;
    case 5:
        r[7] = a ^ value;
        f = kFlags.szp[r[7]];
        break;
    default:
        r[7] = a | value;
        f = kFlags.szp[r[7]];
        break;
    }
}

uint8_t Z80::Inc(uint8_t v) {
    const uint8_t result = static_cast<uint8_t>(v + 1);
    f = static_cast<uint8_t>((f & kC) | (result & (kS | kX | kY)) | (result == 0 ? kZ : 0) | ((result & 0x0F) == 0 ? kH : 0) |
                             (result == 0x80 ? kPV : 0));
    return result;
}

uint8_t Z80::Dec(uint8_t v) {
    const uint8_t result = static_cast<uint8_t>(v - 1);
    f = static_cast<uint8_t>((f & kC) | kN | (result & (kS | kX | kY)) | (result == 0 ? kZ : 0) |
                             ((result & 0x0F) == 0x0F ? kH : 0) | (result == 0x7F ? kPV : 0));
    return result;
}

uint8_t Z80::Rotate(unsigned op, uint8_t v) {
    uint8_t result, carry;
    switch (op) {
    case 0:
        carry = v >> 7;
        result = static_cast<uint8_t>((v << 1) | carry);
        break;
    case 1:
        carry = v & 1;
        result = static_cast<uint8_t>((v >> 1) | (carry << 7));
        break;
    case 2:
        carry = v >> 7;
        result = static_cast<uint8_t>((v << 1) | (f & kC));
        break;
    case 3:
        carry = v & 1;
        result = static_cast<uint8_t>((v >> 1) | ((f & kC) << 7));
        break;
    case 4:
        carry = v >> 7;
        result = static_cast<uint8_t>(v << 1);
        break;
    case 5:
        carry = v & 1;
        result = static_cast<uint8_t>((v >> 1) | (v & 0x80));
        break;
    case 6:
        carry = v >> 7;
        result = static_cast<uint8_t>((v << 1) | 1);
        break;
    default:
        carry = v & 1;
        result = v >> 1;
        break;
    }
    f = kFlags.szp[result] | carry;
    return result;
}

void Z80::Add16(unsigned prefix, uint16_t value) {
    const uint16_t hl = Index(prefix);
    const unsigned sum = hl + value;
    f = static_cast<uint8_t>((f & (kS | kZ | kPV)) | (((hl ^ value ^ sum) >> 8) & kH) | ((sum >> 16) & kC) |
                             ((sum >> 8) & (kX | kY)));
    SetIndex(prefix, static_cast<uint16_t>(sum));
}

void Z80::AdcHL(uint16_t value) {
    const uint16_t hl = HL();
    const unsigned sum = hl + value + (f & kC);
    const uint16_t result = static_cast<uint16_t>(sum);
    f = static_cast<uint8_t>(((result >> 8) & (kS | kX | kY)) | (result == 0 ? kZ : 0) | (((hl ^ value ^ result) >> 8) & kH) |
                             (((~(hl ^ value) & (hl ^ result)) & 0x8000) ? kPV : 0) | ((sum >> 16) & kC));
    SetHL(result);
}

void Z80::SbcHL(uint16_t value) {
    const uint16_t hl = HL();
    const unsigned difference = hl - value - (f & kC);
    const uint16_t result = static_cast<uint16_t>(difference);
    f = static_cast<uint8_t>(((result >> 8) & (kS | kX | kY)) | (result == 0 ? kZ : 0) | (((hl ^ value ^ result) >> 8) & kH) |
                             ((((hl ^ value) & (hl ^ result)) & 0x8000) ? kPV : 0) | kN | ((difference >> 16) & kC));
    SetHL(result);
}

void Z80::RotateA(unsigned op) {
    uint8_t carry;
    switch (op) {
    case 0:
        carry = r[7] >> 7;
        r[7] = static_cast<uint8_t>((r[7] << 1) | carry);
        break;
    case 1:
        carry = r[7] & 1;
        r[7] = static_cast<uint8_t>((r[7] >> 1) | (carry << 7));
        break;
    case 2:
        carry = r[7] >> 7;
        r[7] = static_cast<uint8_t>((r[7] << 1) | (f & kC));
        break;
    default:
        carry = r[7] & 1;
        r[7] = static_cast<uint8_t>((r[7] >> 1) | ((f & kC) << 7));
        break;
    }
    f = static_cast<uint8_t>((f & (kS | kZ | kPV)) | carry | (r[7] & (kX | kY)));
}

void Z80::Daa() {
    const uint8_t a = r[7];
    uint8_t adjust = 0, carry = f & kC;
    if ((f & kH) || (a & 0x0F) > 9) {
        adjust |= 0x06;
    }
    if (carry || a > 0x99) {
        adjust |= 0x60;
        carry = kC;
    }
    const uint8_t result = (f & kN) ? static_cast<uint8_t>(a - adjust) : static_cast<uint8_t>(a + adjust);
    f = static_cast<uint8_t>(kFlags.szp[result] | carry | (f & kN) | ((a ^ result) & kH));
    r[7] = result;
}

void Z80::Cpl() {
    r[7] = ~r[7];
    f = static_cast<uint8_t>((f & (kS | kZ | kPV | kC)) | kH | kN | (r[7] & (kX | kY)));
}

void Z80::Scf() {
    f = static_cast<uint8_t>((f & (kS | kZ | kPV)) | kC | (r[7] & (kX | kY)));
}

void Z80::Ccf() {
    f = static_cast<uint8_t>(((f & (kS | kZ | kPV | kC)) | ((f & kC) ? kH : 0) | (r[7] & (kX | kY))) ^ kC);
}

void Z80::Bit(unsigned bit, uint8_t value, uint8_t undocumented) {
    f = static_cast<uint8_t>((f & kC) | kH | (kFlags.szp[value & (1u << bit)] & ~(kX | kY)) | (undocumented & (kX | kY)));
}

void Z80::Neg() {
    const uint8_t a = r[7];
    r[7] = 0;
    Alu(2, a);
}

void Z80::LoadAFromIR(uint8_t value) {
    r[7] = value;
    f = static_cast<uint8_t>((f & kC) | (kFlags.szp[r[7]] & ~kPV) | (iff2 ? kPV : 0));
}

void Z80::Rrd() {
    const uint8_t m = Rd(HL());
    Wr(HL(), static_cast<uint8_t>((r[7] << 4) | (m >> 4)));
    r[7] = static_cast<uint8_t>((r[7] & 0xF0) | (m & 0x0F));
    f = static_cast<uint8_t>((f & kC) | kFlags.szp[r[7]]);
}

void Z80::Rld() {
    const uint8_t m = Rd(HL());
    Wr(HL(), static_cast<uint8_t>((m << 4) | (r[7] & 0x0F)));
    r[7] = static_cast<uint8_t>((r[7] & 0xF0) | (m >> 4));
    f = static_cast<uint8_t>((f & kC) | kFlags.szp[r[7]]);
}

bool Z80::BlockLoad(int step, bool repeat) {
    const uint8_t value = Rd(HL());
    Wr(DE(), value);
    SetHL(static_cast<uint16_t>(HL() + step));
    SetDE(static_cast<uint16_t>(DE() + step));
    SetBC(static_cast<uint16_t>(BC() - 1));
    const uint8_t n = static_cast<uint8_t>(value + r[7]);
    f = static_cast<uint8_t>((f & (kS | kZ | kC)) | (BC() ? kPV : 0) | (n & kX) | ((n & 0x02) ? kY : 0));
    return repeat && BC();
}

bool Z80::BlockCompare(int step, bool repeat) {
    const uint8_t value = Rd(HL());
    const uint8_t result = static_cast<uint8_t>(r[7] - value);
    const uint8_t half = (r[7] ^ value ^ result) & kH;
    SetHL(static_cast<uint16_t>(HL() + step));
    SetBC(static_cast<uint16_t>(BC() - 1));
    const uint8_t n = static_cast<uint8_t>(result - (half ? 1 : 0));
    f = static_cast<uint8_t>((f & kC) | kN | (result & kS) | (result == 0 ? kZ : 0) | half | (BC() ? kPV : 0) | (n & kX) |
                             ((n & 0x02) ? kY : 0));
    return repeat && BC() && result != 0;
}

unsigned Z80::TakeInterrupt() {
    if (!(m_interrupt && iff1 && !m_afterEI)) {
        return 0;
    }
    if (!m_level) {
        m_interrupt = false;
    }
    halted = false;
    iff1 = iff2 = false;
    refresh++;
    Push(pc);
    if (mode == 2) {
        pc = Read16(static_cast<uint16_t>((i << 8) | 0xFF));
        return 19;
    }
    pc = 0x0038; // (modes 0 and 1: nothing drives the bus, which reads as RST 38h)
    return 13;
}

void Z80::Serialize(Archive &ar) {
    ar.Mark(0x5A383020);
    ar.Pod(r);
    ar.Pod(f);
    ar.Pod(r2);
    ar.Pod(f2);
    ar.Pod(ix);
    ar.Pod(iy);
    ar.Pod(sp);
    ar.Pod(pc);
    ar.Pod(i);
    ar.Pod(refresh);
    ar.Pod(iff1);
    ar.Pod(iff2);
    ar.Pod(halted);
    ar.Pod(mode);
    ar.Pod(m_interrupt);
    ar.Pod(m_afterEI);
    ar.Pod(cycles);
}

} // namespace cps2recomp
