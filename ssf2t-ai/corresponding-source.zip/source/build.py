from pathlib import Path
import argparse,json,subprocess,shutil,os,hashlib,zipfile
p=argparse.ArgumentParser();p.add_argument('--cxx',default=os.environ.get('EMXX','em++'));p.add_argument('--out',type=Path,default=Path('build'));a=p.parse_args();h=Path(__file__).resolve().parent;c=json.loads((h/'build-config.json').read_text());out=a.out.resolve();out.mkdir(parents=True,exist_ok=True)
maps=[]
for folder,canonical in [('lib','/src/lib'),('native','/src/native'),('strict','/src/glue/strict')]:
 for flag in ['-ffile-prefix-map=','-fmacro-prefix-map=']:maps.append(flag+(h/folder).as_posix()+'='+canonical)
args=maps+c['options']+['-I'+(h/n).as_posix()for n in c['includes']]+[(h/n).as_posix()for n in c['sources']]+['-o',(out/'ssf2t-native.js').as_posix()];subprocess.run([a.cxx,*args],cwd=h,check=True)
for f in (h/'web').iterdir():shutil.copyfile(f,out/f.name)
digest=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
with zipfile.ZipFile(out/'corresponding-source.zip','w',zipfile.ZIP_DEFLATED,compresslevel=9)as z:
 for name in json.loads((h/'source-files.json').read_text()):
  item=zipfile.ZipInfo('source/'+name,(2026,11,26,0,0,0));item.compress_type=zipfile.ZIP_DEFLATED;z.writestr(item,(h/name).read_bytes())
proof={'kind':'rebuild-artifact-hashes','runtimeChecksRerun':False,'capturedReferenceEvidence':'reference-proof.json','artifacts':{name:{'bytes':(out/name).stat().st_size,'sha256':digest(out/name)}for name in ['ssf2t-native.js','ssf2t-native.wasm','bridge.js','audio-worklet.js','ai-combat.js','ai-shortcuts.js','rom-loader.js','rom-manifest.js','corresponding-source.zip']}}
(out/'source-proof.json').write_text(json.dumps(proof,indent=2),encoding='utf8')
for name in ['SOURCE-LICENSES.md','about.html']:
 text=(out/name).read_text(encoding='utf8')
 for link in ['source-proof.json','reference-proof.json','SCOPE.md','SOURCE-LICENSES.md','corresponding-source.zip']:text=text.replace(link,link+'?v='+digest(out/link)[:16])
 (out/name).write_text(text,encoding='utf8')
index=(out/'index.html').read_text(encoding='utf8').replace('__SSF2T_WASM_SHA256__',digest(out/'ssf2t-native.wasm')).replace('about.html','about.html?v='+digest(out/'about.html')[:16])
for name in ['bridge.js','audio-worklet.js','ai-combat.js','ai-shortcuts.js','rom-loader.js','rom-manifest.js','ssf2t-native.js']:index=index.replace('src="'+name+'"','src="'+name+'?v='+digest(out/name)[:16]+'"')
(out/'index.html').write_text(index,encoding='utf8')
print('Built ROM-free native browser game in',out)
