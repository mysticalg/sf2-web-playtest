# Ordinary-input arcade and common-flow proof

Install Node and Playwright (`npm install playwright`), serve the rebuilt web package, then run:

```powershell
$env:SSF_URL = "http://127.0.0.1:8000/?manual=1"
$env:SSF_ROM = "C:/path/to/ssf2t.zip"
node test-arcade.cjs
$env:SSF_TRACE = "char0-policy0"
node test-arcade.cjs
$env:SSF_TRACE = "continue-inputs"
node test-arcade.cjs
```

The clear tape is tool-assisted ordinary stick/button input selected by offline planning. This independent browser replay contains no planning or state restoration. The only setting write selects the original easiest operator difficulty after native frame 3001. Health, result, stage, RNG and timer are never written. Ryu genuinely wins 24 rounds and 12 matches, defeats the native CPU Akuma intrusion and reaches his original ending, staff roll and title. This proves one complete Ryu playthrough, not all fighter endings. The other tapes genuinely lose and respectively time out Continue or press Start to spend a credit and resume the match. No ROM assets are contained in these JSON input patterns, observed state values or image hashes.

Every recorded state and all selected reference RGB pictures must match. Runtime fallback and browser errors must remain zero. Output contains test evidence and screenshots; the test uses the actual local file chooser and verifies no non-GET network request. `SSF_OUT` sets its output directory. The captured native reference used the same reconstructed renderer/mixer, so equality does not establish hardware DSP/GPU parity.

Additional genuine ordinary-input common outcomes: `SSF_TRACE=char10-policy10` (Balrog KO and victory pose), `char11-policy10` (Vega KO and victory pose), and `char1-policy99` (idle Honda genuinely loses, Continue/Game Over/title). These tapes contain no diagnostic ladder/health/result/stage/RNG/timer writes. Only the original easiest operator difficulty is selected. The Ryu clear and all three new common outcomes now match a full Mode::Blocks oracle for BOTH CPUs: every 68000 and Z80 instruction is interpreted offline. Earlier Ryu loss/Continue fixtures retain their explicitly labelled Native-mode reference, which uses translated functions plus original-instruction fallback at untranslated addresses. Neither reference establishes hardware graphics or DSP parity.

Special-input recovery: run `node test-mechanics.cjs` with the same SSF_URL/SSF_ROM settings. Six dual-stick input-only tapes compare1,136states and570RGB pictures against an independent full instruction oracle. There are no game RAM writes, state loads or forced results. Command-family sweeps include some KO/round transitions and do not prove every attempted motion activated a move.


Ken recovery: run `node qa/test-ken.cjs` with SSF_URL and SSF_ROM set. It replays the original input-only5500-frame dispatch regression. For the genuine24round/12match clear set SSF_FIXTURE=./ken-arcade-fixture.json; this68,425-frame tape includes the ending and return to title. Both fixtures set only original operator difficulty after frame3001, with no health/stage/ladder/RNG/timer writes or replay state loads. The complete clear was planned offline; the replay contains ordinary controller buttons only.


Cammy: set SF2_NATIVE_URL and SF2_NATIVE_ROM, then run `node qa/test-cammy.cjs`. This genuine68473-frame clear verifies2282states/693RGB pictures, counts24round wins/no losses, confirms the native CPUAkuma final opponent, ending and return to title, and checks that ROM selection generates GETrequests only. No replay health/stage/ladder/RNG/timer/results writes or state loads. Only original operator difficulty1 is selected.

Guile reversal regression: node qa/ssf2t-guile-charge.browser.cjs. Full original-input clear: node qa/ssf2t-guile-arcade.browser.cjs. Set SF2_NATIVE_URL and SF2_NATIVE_ROM; install Playwright. Planning generated the input tapes offline; these browser replays do not plan or load states.
