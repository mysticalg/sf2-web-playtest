# Ordinary-input arcade and common-flow proof

Install Node and Playwright (`npm install playwright`), serve the rebuilt web package, then run:

```powershell
$env:SSF_URL = "http://127.0.0.1:8000/?manual=1"
$env:SSF_ROM = "C:/path/to/ssf2t.zip"
node test-arcade.cjs
$env:SSF_TRACE = "char0-policy0"
node test-arcade.cjs
$env:SSF_TRACE = "continue-inputs"
node test-arcade.cjs
```

The clear tape is tool-assisted ordinary stick/button input selected by offline planning. This independent browser replay contains no planning or state restoration. The only setting write selects the original easiest operator difficulty after native frame 3001. Health, result, stage, RNG and timer are never written. Ryu genuinely wins 24 rounds and 12 matches, defeats the native CPU Akuma intrusion and reaches his original ending, staff roll and title. This proves one complete Ryu playthrough, not all fighter endings. The other tapes genuinely lose and respectively time out Continue or press Start to spend a credit and resume the match. No ROM assets are contained in these JSON input patterns, observed state values or image hashes.

Every recorded state and all 1,032 reference RGB pictures must match. Runtime fallback and browser errors must remain zero. Output contains test evidence and screenshots; the test uses the actual local file chooser and verifies no non-GET network request. `SSF_OUT` sets its output directory. The captured native reference used the same reconstructed renderer/mixer, so equality does not establish hardware DSP/GPU parity.
