# Rebuild the native Europe 940223 browser candidate

Activate an Emscripten SDK environment, then run `python build.py`. Optional: `--cxx /path/to/em++.exe --out /path/to/output`. Serve the output over HTTP(S), then select your own original Europe 940223 ssf2t.zip. No ROM is needed to compile this source package.

The source includes every compiled static native function, exact support and web loader, all required reconstruction headers/source, and the GPL licence. The 68000 and Z80 opcode decoders and interpreter scheduling implementations are excluded. The historical fixed-site Interpret ABI contains only explicit constant-site arithmetic, not an opcode decoder. No raw archive, program/data/opcode region, graphics/sample region or private preload pack is included. Addressed native function semantics derive from the matching original European game; the original game remains Capcom material, not newly claimed GPL art.

Reconstruction reference: tmcleroy/cps2recomp e266571432b12552a986fb66e702810df32947b3. Runtime/reconstruction code is GPL-3.0-only with original notices retained. The MAME-derived CPS2 cipher is BSD-3-Clause; other third-party notices are retained in their source files. See the candidate SOURCE-LICENSES.md for provenance and tested limitations.

AI presentation checks: `node qa/ssf2t-ai-combat.test.cjs`. For browser checks serve the rebuilt directory, set SF2_NATIVE_URL to its index URL with ?manual=1, set SF2_NATIVE_ROM to your verified local ZIP and run `node qa/ssf2t-ai-effects.browser.cjs`. Playwright is required. These tests do not modify native game memory.
