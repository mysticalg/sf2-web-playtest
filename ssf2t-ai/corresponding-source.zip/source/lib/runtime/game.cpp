// SPDX-License-Identifier: GPL-3.0-only
// Copyright (C) 2026 Tommy McLeroy. Part of cps2recomp.

#include "game.h"

#include <algorithm>
#include <cstdio>
#include <cstdlib>
#include <cstring>
#include <filesystem>
#include <fstream>
#include <map>
#include <set>
#include <sstream>

namespace cps2recomp {

Game &TheGame() {
    static Game game;
    return game;
}

namespace {
    uint8_t *g_ram = nullptr;
    uint8_t *g_videoRam = nullptr;
} // namespace
void SetRam(uint8_t *ram, uint8_t *videoRam) {
    g_ram = ram;
    g_videoRam = videoRam;
}
uint8_t *Ram(uint32_t address) {
    // (a game that keeps its variables in the video memory, as Raizing's do: its address as the 68000 has it)
    const uint32_t at = address & 0xFFFFFF;
    if (at >= kVideoRamLow && at < kVideoRamHigh && g_videoRam) {
        return g_videoRam + (at - kVideoRamLow);
    }
    return g_ram + (address & 0xFFFF);
}

namespace {
    uint8_t *g_program = nullptr;
    uint32_t g_programSize = 0;
} // namespace
void SetProgram(uint8_t *program, uint32_t size) {
    g_program = program;
    g_programSize = size;
}
namespace {
    uint8_t *g_opcodes = nullptr;
    uint8_t *g_extra = nullptr, *g_extraOpcodes = nullptr;
    uint32_t g_extraSize = 0, g_extraBase = 0;
} // namespace
void SetProgramOpcodes(uint8_t *opcodes) {
    g_opcodes = opcodes;
}
uint8_t *ProgramOpcodes(uint32_t address) {
    if (g_extraOpcodes && address >= g_extraBase && address - g_extraBase < g_extraSize) {
        return g_extraOpcodes + (address - g_extraBase);
    }
    return g_opcodes + address;
}
void SetExtraProgram(uint8_t *program, uint8_t *opcodes, uint32_t size, uint32_t base) {
    g_extra = program;
    g_extraOpcodes = opcodes;
    g_extraSize = size;
    g_extraBase = base;
}
uint8_t *ExtraProgram(uint32_t address) {
    return g_extra ? g_extra + address : nullptr;
}
uint8_t *ExtraOpcodes(uint32_t address) {
    return g_extraOpcodes ? g_extraOpcodes + address : nullptr;
}
uint32_t ExtraProgramSize() {
    return g_extraSize;
}
uint32_t ExtraBase() {
    return g_extraBase;
}
namespace {
    SoundBoard *g_extraSound = nullptr;
}
void SetExtraSound(SoundBoard *board) {
    g_extraSound = board;
}
SoundBoard *ExtraSound() {
    return g_extraSound;
}
namespace {
    PointerLoadFn g_pointerLoads = nullptr;
    uint32_t g_pointerLow = 0xFFFFFFFF, g_pointerHigh = 0;
} // namespace
void SetPointerLoads(PointerLoadFn fn, uint32_t low, uint32_t high) {
    g_pointerLoads = fn;
    g_pointerLow = low;
    g_pointerHigh = high;
}
PointerLoadFn PointerLoads(uint32_t &low, uint32_t &high) {
    low = g_pointerLow;
    high = g_pointerHigh;
    return g_pointerLoads;
}
uint32_t ProgramSize() {
    return g_programSize;
}
uint8_t *Program(uint32_t address) {
    if (g_extra && address >= g_extraBase && address - g_extraBase < g_extraSize) {
        return g_extra + (address - g_extraBase);
    }
    return g_program + address;
}
bool InProgram(uint32_t address) {
    return address < g_programSize || (g_extra && address >= g_extraBase && address - g_extraBase < g_extraSize);
}

namespace {
    std::map<std::string, int> g_on;
    std::set<std::string> g_aids; // the features marked kFeatureTraining (LoadFeatures)
    bool g_fastForward = false;
    bool g_runningAhead = false;
    int g_slowMotion = 1, g_fastMotion = 1;
    std::string g_settingsPath;

    std::string Trim(const std::string &s) {
        const size_t a = s.find_first_not_of(" \t\r"), b = s.find_last_not_of(" \t\r");
        return a == std::string::npos ? "" : s.substr(a, b - a + 1);
    }
} // namespace

std::vector<recomp::FeatureInfo> FeatureList() {
    std::vector<recomp::FeatureInfo> list;
    for (const Feature &feature : TheGame().features) {
        recomp::FeatureInfo info{feature.name, feature.category, feature.title, feature.description, feature.flags, {}};
        info.choices.assign(feature.choices.begin(), feature.choices.end());
        list.push_back(info);
    }
    return list;
}

const std::string &SettingsPath() {
    return g_settingsPath;
}

void LoadFeatures(const std::string &settingsPath, const std::string &list) {
    g_settingsPath = settingsPath;
    g_on.clear();
    g_aids.clear();
    for (const Feature &feature : TheGame().features) {
        if (feature.flags & kFeatureTraining) {
            g_aids.insert(feature.name);
        }
    }
    // (the rules the launcher follows too: recomp-common/settings.h)
    recomp::Ini settings(settingsPath);
    settings.load();
    if (TheGame().migrateSettings) TheGame().migrateSettings(settings);
    const std::vector<int> values = recomp::FeatureValues(settings, FeatureList());
    for (size_t i = 0; i < values.size(); i++) {
        g_on[TheGame().features[i].name] = values[i];
    }
    std::stringstream names(list);
    std::string name;
    while (std::getline(names, name, ',')) {
        name = Trim(name);
        if (!name.empty()) {
            const bool off = name[0] == '-';
            // (NAME, -NAME, or NAME=N for one of a feature's choices)
            const size_t eq = name.find('=');
            std::string key = eq == std::string::npos ? name.substr(off ? 1 : 0) : name.substr(0, eq);
            int value = eq == std::string::npos ? !off : atoi(name.c_str() + eq + 1);
            if (TheGame().migrateOption) TheGame().migrateOption(key, value);
            g_on[key] = value;
        }
    }
}

bool FeatureOn(const char *name) {
    return FeatureValue(name) != 0;
}

int FeatureSetting(const char *name) {
    const auto it = g_on.find(name);
    return it == g_on.end() ? 0 : it->second;
}

int FeatureValue(const char *name) {
    const auto it = g_on.find(name);
    if (it == g_on.end() || it->second == 0) {
        return 0;
    }
    // (a training aid, outside a training session: off)
    if (TheGame().inTraining && g_aids.count(it->first) && !TheGame().inTraining()) {
        return 0;
    }
    return it->second;
}

void TrainingAids(std::initializer_list<const char *> names) {
    for (const char *name : names) {
        for (Feature &feature : TheGame().features) {
            if (!strcmp(feature.name, name)) {
                feature.flags |= kFeatureTraining;
            }
        }
    }
}

void OwnFeatures(std::initializer_list<const char *> names) {
    for (const char *name : names) {
        for (Feature &feature : TheGame().features) {
            if (!strcmp(feature.name, name)) {
                feature.flags |= kFeatureOwn;
            }
        }
    }
}

void EndSessionFeatures() {
    for (const Feature &feature : TheGame().features) {
        if (feature.flags & kFeatureSession) {
            g_on[feature.name] = 0;
        }
    }
}

void SetFastForward(bool on) {
    g_fastForward = on;
}
bool FastForward() {
    return g_fastForward;
}

bool RunningAhead() {
    return g_runningAhead;
}
void SetRunningAhead(bool on) {
    g_runningAhead = on;
}

namespace {
    std::function<bool()> g_onlinePlay;
}
bool OnlinePlay() {
    return g_onlinePlay && g_onlinePlay();
}
void OnlinePlayFrom(std::function<bool()> query) {
    g_onlinePlay = std::move(query);
}

namespace {
std::string g_multiGame, g_playerFolder;
int g_programEnded = -1;
int64_t g_nextGameAsked = -1;
} // namespace
void SetMultiGame(const std::string &spec) {
    g_multiGame = spec;
}
const std::string &MultiGame() {
    return g_multiGame;
}
void SetPlayerFolder(const std::string &folder) {
    g_playerFolder = folder;
}
const std::string &PlayerFolder() {
    return g_playerFolder;
}
namespace {
void (*g_folderOpener)(const std::string &) = nullptr;
}
void SetFolderOpener(void (*open)(const std::string &folder)) {
    g_folderOpener = open;
}
bool OpenFolder(const std::string &folder) {
    if (!g_folderOpener) {
        return false;
    }
    g_folderOpener(folder);
    return true;
}
void EndProgram(int code) {
    g_programEnded = code;
}
int ProgramEnded() {
    return g_programEnded;
}
void AskNextGame(int64_t tick) {
    g_nextGameAsked = tick;
}
int64_t NextGameAsked() {
    return g_nextGameAsked;
}

void SetSlowMotion(int by) {
    g_slowMotion = by < 1 ? 1 : by;
}
int SlowMotion() {
    return g_slowMotion;
}
void SetFastMotion(int times) {
    g_fastMotion = times < 1 ? 1 : times;
}
int FastMotion() {
    return g_fastMotion;
}

namespace {
// A feature whose switch is on the launcher's first page: that switch too, in launcher.ini beside settings.ini, or
// the launcher would turn it back the next time the game is started
void KeepFirstPage(const char *name, bool on) {
    for (const Feature &feature : TheGame().features) {
        if ((feature.flags & kFeatureFirstPage) && !strcmp(feature.name, name)) {
            const std::string launcherIni = (std::filesystem::path(g_settingsPath).parent_path() / "launcher.ini").string();
            if (std::filesystem::exists(launcherIni)) {
                recomp::Ini prefs(launcherIni);
                prefs.load();
                prefs.set("video", name, on ? "1" : "0");
                prefs.save();
            }
        }
    }
}
} // namespace

void SetFeature(const char *name, bool on) {
    SetFeatureValue(name, on ? 1 : 0);
}

void SetFeatureValue(const char *name, int value) {
    const bool on = value != 0;
    g_on[name] = value;
    // (one of a category's exclusive features at a time, as in the launcher)
    for (const Feature &changed : TheGame().features) {
        if (on && (changed.flags & kFeatureExclusive) && !strcmp(changed.name, name)) {
            for (const Feature &other : TheGame().features) {
                if ((other.flags & kFeatureExclusive) && !strcmp(other.category, changed.category) && strcmp(other.name, name)) {
                    g_on[other.name] = 0;
                }
            }
        }
    }
    if (g_settingsPath.empty()) {
        return;
    }
    // The file as it is but for this feature (and, coming from a preset, the others written down as they
    // were): as the launcher writes it
    const std::vector<recomp::FeatureInfo> features = FeatureList();
    for (size_t i = 0; i < features.size(); i++) {
        if (features[i].name == name) {
            recomp::Ini settings(g_settingsPath);
            settings.load();
            recomp::SetFeature(settings, features, i, value);
            settings.save();
        }
    }
    KeepFirstPage(name, on);
}

void SetFeatureForNow(const char *name, int value) {
    g_on[name] = value;
}

void ResetFeatures() {
    // (every feature as the launcher's default preset, Enhanced, has it)
    const std::vector<recomp::FeatureInfo> features = FeatureList();
    recomp::Ini settings(g_settingsPath);
    if (!g_settingsPath.empty()) {
        settings.load();
    }
    recomp::SetPreset(settings, features, "enhanced");
    const std::vector<int> values = recomp::FeatureValues(settings, features);
    for (size_t i = 0; i < values.size(); i++) {
        g_on[features[i].name] = values[i];
    }
    if (g_settingsPath.empty()) {
        return;
    }
    settings.save();
    for (size_t i = 0; i < values.size(); i++) {
        KeepFirstPage(features[i].name.c_str(), values[i] != 0);
    }
}

namespace {
    std::vector<HudLine> g_hud;
    uint64_t g_hudSerial = 0;
} // namespace

namespace {
    std::vector<HudBox> g_boxes;
} // namespace
void SetBoxes(std::vector<HudBox> boxes) {
    if (boxes != g_boxes) {
        g_boxes = std::move(boxes);
        g_hudSerial++;
    }
}
const std::vector<HudBox> &Boxes() {
    return g_boxes;
}

void SetHud(std::vector<HudLine> lines) {
    if (lines != g_hud) {
        g_hud = std::move(lines);
        g_hudSerial++;
    }
}
const std::vector<HudLine> &Hud() {
    return g_hud;
}
uint64_t HudSerial() {
    return g_hudSerial;
}

} // namespace cps2recomp
