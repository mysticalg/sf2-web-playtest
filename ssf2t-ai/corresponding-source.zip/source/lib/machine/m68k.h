// SPDX-License-Identifier: GPL-3.0-only
// Copyright (C) 2026 Tommy McLeroy. Part of cps2recomp.
//
// The main CPU: a Motorola 68000, which runs the game's program from ROM.
//
// An interpreter: Step runs one instruction (or takes an interrupt) and says how many clock cycles it took.
// Bus and address errors are not modelled. The board deciphers what the CPU reads as program (instruction
// words, and data addressed relative to the PC); everything else it reads is the ROM as it is. So the bus
// has two kinds of read.
#pragma once

#include <cstdint>
#include <utility>
#include <vector>

namespace cps2recomp {

class Archive;

// What the CPU is connected to: 24-bit addresses, big-endian words
struct M68KBus {
    virtual ~M68KBus() = default;
    virtual uint8_t Read8(uint32_t address) = 0;
    virtual uint16_t Read16(uint32_t address) = 0;
    virtual void Write8(uint32_t address, uint8_t value) = 0;
    virtual void Write16(uint32_t address, uint16_t value) = 0;
    // A word read as program (deciphered)
    virtual uint16_t Fetch16(uint32_t address) = 0;
    // The CPU takes the interrupt of this level
    virtual void InterruptAck(unsigned level) {}
    // Trial execution in the block checker: MMIO writes may change another address's read (a hardware multiplier).
    // Reflect only those dependencies, then restore them before the reference interpreter runs.
    virtual void BeginCheck() {}
    virtual void CheckWrite(uint32_t address, unsigned size, uint32_t value) {}
    virtual void EndCheck() {}
};

class M68K;
// Watches (runtime/lift.h, AddWatch): a byte for each word of the program, set where one is; and the call
extern const uint8_t *g_watchMap;
extern uint32_t g_watchMapSize;
void RunWatch(M68K &c, uint32_t address);
// A translated routine (runtime/native.h): runs from the block at cpu.pc until it leaves the routine
using NativeFn = void (*)(M68K &);

class M68K {
public:
    explicit M68K(M68KBus &bus)
        : bus(bus) {}

    // How Run goes about it
    enum class Mode {
        Interpreter, // an instruction at a time
        Blocks,      // the interpreter, stopping only where translated code would (the reference for Native)
        Native,      // translated code; the interpreter for what has no translation
        Check,       // both, a block at a time, compared (the check build only)
    };

    // The reset line: the stack pointer and PC from the first two vectors
    void Reset(bool hard);
    // The level on the interrupt lines (0: none); taken before an instruction when above the mask in SR
    void SetInterruptLevel(uint8_t level) {
        m_interruptLevel = level;
    }
    uint8_t InterruptLevel() const {
        return m_interruptLevel;
    }
    // One instruction or interrupt; the clock cycles it took (not added to `cycles`)
    uint32_t Step();
    // Runs until `cycles` reaches `until` (a little past it: to the end of the instruction or block)
    void Run(uint64_t until, Mode mode);
    // For translated code: the instruction at `address` done by the interpreter (the rare ones)
    void Interpret(uint32_t address);

    uint32_t d[8] = {}, a[8] = {}; // a[7] is the stack pointer in use
    uint32_t otherSP = 0;          // the user or supervisor stack pointer not in use
    uint32_t pc = 0;               // of the next instruction
    bool flagC = false, flagV = false, flagZ = false, flagN = false, flagX = false;
    bool supervisor = true, trace = false;
    uint8_t interruptMask = 7;
    bool stopped = false; // (after STOP: until an interrupt)

    uint64_t cycles = 0; // clock cycles since reset
    // The board's bus waits (Machine::SetBoardTiming; docs/TIMING.md): an access outside the board's unwaited range
    // (the ROM, instruction fetches included, work RAM, video RAM, the I/O) is acknowledged a clock late. On CPS-2
    // (its DL-1827, as jtcps2_dtack has it) that range is 500000-7FFFFF; on a classic CPS-1 (its PAL PRG1's /ONE WAIT)
    // 400000-7FFFFF; on a CPS-1 with QSound (PRG2's) F00000-FEFFFF. 1: counted (each word of program an instruction
    // is, each byte or word of data it reads or writes, and an interrupt's acknowledge and fetches); 0: not.
    unsigned busWait = 0;
    uint32_t unwaitedLow = 0x500000, unwaitedHigh = 0x800000;
    bool WaitedFor(uint32_t address) const {
        address &= 0xFFFFFF;
        return address < unwaitedLow || address >= unwaitedHigh;
    }
    // A write in [slowWriteLow, slowWriteHigh) or from slowWriteFrom up waits a clock more: a CPS-1's video RAM and its
    // work RAM, as jotego's jtcps1 has them
    // (docs/TIMING.md). 0, 0: none.
    uint32_t slowWriteLow = 0, slowWriteHigh = 0;
    uint32_t slowWriteFrom = 0x1000000; // (and from here up: a CPS-1's work RAM, FF0000-FFFFFF)
    void WriteWait(uint32_t address) {
        BusWait(address);
        address &= 0xFFFFFF;
        if (busWait && ((address >= slowWriteLow && address < slowWriteHigh) || address >= slowWriteFrom)) {
            cycles += busWait;
            waitsCounted += busWait;
        }
    }
    void BusWait(uint32_t address) {
        if (busWait && WaitedFor(address)) {
            cycles += busWait;
            waitsCounted += busWait;
        }
    }
    uint64_t waitsCounted = 0; // (CPS2RECOMP_BUS_LOG: the waits since the last frame)
    // A one-word instruction that went somewhere else (a short branch taken, RTS, JMP (An), TRAP, RTE): the
    // 68000 fetches two words there in place of the one it had fetched ahead, a word more than the instruction
    // has (translated code adds the same where it jumps; tools/recomp.py). One that always goes (JMP and JSR (An),
    // RTS, RTR, RTE, TRAP) refetches even when where it goes is the next word (a jump table's first entry, say):
    // only a short branch not taken leaves the prefetch as it was.
    unsigned fetchedWords = 0;
    static bool AlwaysGoes(uint16_t op) {
        return (op & 0xFFB8) == 0x4E90 || op == 0x4E75 || op == 0x4E77 || op == 0x4E73 || (op & 0xFFF0) == 0x4E40;
    }
    void RefillWait(uint32_t start) {
        if (busWait && fetchedWords == 1 && (pc != start + 2 || AlwaysGoes(bus.Fetch16(start)))) {
            cycles += busWait;
            waitsCounted += busWait;
        }
    }
    // One instruction by the interpreter, the refetch above counted (every run loop's and check's way of doing one)
    void ExecuteOne() {
        const uint32_t start = pc;
        // (a watch is told before its instruction; not on another game's board, which runs another program)
        if (ownHooked ? ownWatched && start / 2 < ownWatchedSize && ownWatched[start / 2]
                      : g_watchMap && start / 2 < g_watchMapSize && g_watchMap[start / 2]) {
            if (ownHooked) {
                const uint32_t kept = pc;
                pc = start;
                ownWatch(*this);
                pc = kept;
            } else {
                RunWatch(*this, start);
            }
        }
        fetchedWords = 0;
        if (callLog) {
            // (CPS2RECOMP_CALL_LOG: each jsr and bsr the interpreter runs, where from and where to)
            const uint16_t op = bus.Fetch16(start);
            Execute(Fetch());
            if ((op & 0xFFC0) == 0x4E80 || (op & 0xFF00) == 0x6100) {
                callLog(start, pc);
            }
        } else {
            Execute(Fetch());
        }
        RefillWait(start);
    }
    void (*callLog)(uint32_t from, uint32_t to) = nullptr;
    uint64_t budget = 0; // translated code stops at the first block that starts at or after this
    // A wait (runtime/lift.h, Wait): the 68000 does nothing for so many cycles when it is next at `waitResume`
    // with the stack at `waitStack`; interrupts are taken meanwhile as they would be. When the wait is over
    // the byte of work RAM at `waitClears` (if not 0) is cleared.
    uint64_t waitCycles = 0;
    uint32_t waitResume = 0, waitStack = 0, waitClears = 0;
    bool waitArmed = false;
    void FinishWait() {
        if (waitClears) {
            ram[waitClears & 0xFFFF] = 0;
        }
        waitCycles = 0;
        waitClears = 0;
        waitArmed = false;
    }
    unsigned depth = 0;  // of translated routines calling one another on the host's stack

    // A 68000 of another board run beside the game's (runtime/guest.h) has hooks of its own, not the game's (which are at
    // the game's addresses): `ownHooked` a byte for each word of its ROM (not 0: a hook there), `ownHook` called there
    // as a game's hook is (true: it has done the instruction's work, the PC set). Set, the game's hooks are never asked.
    // Such a 68000 runs only on the interpreter (Mode::Interpreter): the translated code is the game's.
    const uint8_t *ownHooked = nullptr;
    uint32_t ownHookedSize = 0; // (bytes of ROM it covers)
    bool (*ownHook)(M68K &c, uint32_t address) = nullptr;
    const void *ownContext = nullptr; // (whose hooks they are, for ownHook)
    // ... and its watches (runtime/guest.h, AddGuestWatches): a byte for each word of its ROM, the function, and what it
    // is told of them (watchContext: a guest's watched instructions; none on the game's own board)
    const uint8_t *ownWatched = nullptr;
    uint32_t ownWatchedSize = 0;
    bool (*ownWatch)(M68K &c) = nullptr;
    void *watchContext = nullptr;
    bool OwnHook(uint32_t address) {
        return address < ownHookedSize && ownHooked[address / 2] && ownHook(*this, address);
    }

    // What translated code reaches without going through the bus (set by the machine)
    M68KBus &bus;
    uint8_t *ram = nullptr;          // FF0000-FFFFFF
    uint8_t *video = nullptr;        // 900000 and up: video RAM (for the check of rewrites that write it)
    // The native interface of the picture this CPU's machine draws (video/native.h): the video library's lifts hand it
    // their records (each machine its own: the spare and guest boards run the same code)
    class NativeVideo *nativeVideo = nullptr;
    uint32_t videoSize = 0;
    const uint8_t *rom = nullptr;    // the program as data
    const uint8_t *opcodes = nullptr; // the program as program
    uint32_t romSize = 0;

    // An address register loaded from memory (movea.l) from `extraLow` to `extraHigh`: the game's sources may change
    // the value (a game that runs another set's code and tables there, whose addresses are that set's own: game.h,
    // SetPointerLoads). Elsewhere, nothing is changed.
    using PointerFn = uint32_t (*)(uint32_t address, uint32_t value);
    PointerFn pointerFrom = nullptr;
    uint32_t extraLow = 0xFFFFFFFF, extraHigh = 0;
    uint32_t PointerLoad(uint32_t address, uint32_t value) const {
        return (address & 0xFFFFFF) - extraLow < extraHigh - extraLow && pointerFrom ? pointerFrom(address & 0xFFFFFF, value) : value;
    }

    // Addresses reached in ways the translator cannot follow (computed jumps, returns, exceptions) that are
    // not yet the start of a translated block; kept when recording is on
    bool recording = false;
    std::vector<uint32_t> newEntries;
    // (for --stats: instructions the interpreter ran while translated code was meant to, and all it ran)
    uint64_t interpreted = 0;
    // ... of which code the game runs in RAM (Champion Edition calls small routines it writes into video RAM): never
    // the ROM's, so never translated
    uint64_t interpretedRam = 0;
    // For finding out who writes somewhere (--watch): writes by the interpreter to addresses from watchLow to
    // watchHigh are reported with the instruction's address. Translated code is not watched (run with
    // --cpu blocks, which does the same things).
    uint32_t watchLow = 1, watchHigh = 0;
    // (CPS2RECOMP_PC_HISTORY=1: the places the run loop last came to, translated routines and instructions the
    // interpreter ran, printed when it meets something that is not an instruction)
    bool keepHistory = false;
    uint32_t history[64] = {};
    unsigned historyAt = 0;
    void Remember(uint32_t place) {
        history[historyAt++ & 63] = place;
    }
    uint32_t instruction = 0; // the address of the instruction the interpreter is doing
    // More than 0 while a rewrite (runtime/lift.h) runs, but not the game's own code it calls: its writes to the video's
    // registers are what the game's code says to them, and are told to the native interface (video/native.h)
    int nativeWrites = 0;

    uint16_t SR() const {
        return static_cast<uint16_t>(flagC | (flagV << 1) | (flagZ << 2) | (flagN << 3) | (flagX << 4) | (interruptMask << 8) |
                                     (supervisor << 13) | (trace << 15));
    }
    void SetSR(uint16_t value) {
        flagC = value & 1;
        flagV = value & 2;
        flagZ = value & 4;
        flagN = value & 8;
        flagX = value & 16;
        interruptMask = (value >> 8) & 7;
        trace = value & 0x8000;
        const bool super = value & 0x2000;
        if (super != supervisor) {
            std::swap(a[7], otherSP);
            supervisor = super;
        }
    }
    void Serialize(Archive &ar); // save states (runtime/state.h)

    // --- arithmetic and flags, shared by the interpreter and translated code ---
    // Sizes: 0 a byte, 1 a word, 2 a long word

    bool Condition(unsigned cc) const {
        switch (cc) {
        case 0: return true;
        case 1: return false;
        case 2: return !flagC && !flagZ;
        case 3: return flagC || flagZ;
        case 4: return !flagC;
        case 5: return flagC;
        case 6: return !flagZ;
        case 7: return flagZ;
        case 8: return !flagV;
        case 9: return flagV;
        case 10: return !flagN;
        case 11: return flagN;
        case 12: return flagN == flagV;
        case 13: return flagN != flagV;
        case 14: return !flagZ && flagN == flagV;
        default: return flagZ || flagN != flagV;
        }
    }
    uint32_t Add(uint32_t x, uint32_t y, unsigned size, bool withX, bool keepZ) {
        const uint64_t sum = static_cast<uint64_t>(x & kMask[size]) + (y & kMask[size]) + (withX && flagX);
        const uint32_t result = static_cast<uint32_t>(sum) & kMask[size];
        flagC = flagX = (sum >> (kBytes[size] * 8)) & 1;
        flagV = (~(x ^ y) & (x ^ result) & kSign[size]) != 0;
        flagN = result & kSign[size];
        flagZ = keepZ ? (flagZ && result == 0) : result == 0;
        return result;
    }
    // x - y
    uint32_t Sub(uint32_t x, uint32_t y, unsigned size, bool withX, bool keepZ, bool setX = true) {
        const uint64_t difference = static_cast<uint64_t>(x & kMask[size]) - (y & kMask[size]) - (withX && flagX);
        const uint32_t result = static_cast<uint32_t>(difference) & kMask[size];
        flagC = (difference >> (kBytes[size] * 8)) & 1;
        if (setX) {
            flagX = flagC;
        }
        flagV = ((x ^ y) & (x ^ result) & kSign[size]) != 0;
        flagN = result & kSign[size];
        flagZ = keepZ ? (flagZ && result == 0) : result == 0;
        return result;
    }
    void Logic(uint32_t result, unsigned size) {
        flagN = result & kSign[size];
        flagZ = (result & kMask[size]) == 0;
        flagV = flagC = false;
    }
    // kind: 0 arithmetic shift, 1 logical shift, 2 rotate through X, 3 rotate
    uint32_t Shift(unsigned kind, bool left, uint32_t value, unsigned count, unsigned size) {
        const uint32_t sign = kSign[size];
        value &= kMask[size];
        flagV = false;
        flagC = kind == 2 ? flagX : false;
        for (unsigned i = 0; i < count; i++) {
            const bool out = left ? (value & sign) : (value & 1);
            uint32_t in = 0;
            switch (kind) {
            case 0: in = left ? 0 : (value & sign); break;
            case 1: in = 0; break;
            case 2: in = flagX ? (left ? 1 : sign) : 0; break;
            default: in = out ? (left ? 1 : sign) : 0; break;
            }
            const uint32_t before = value;
            value = left ? ((value << 1) & kMask[size]) | in : (value >> 1) | in;
            flagC = out;
            if (kind != 3) {
                flagX = out;
            }
            if (kind == 0 && left && ((before ^ value) & sign)) {
                flagV = true; // (the sign changed at some point)
            }
        }
        flagN = value & sign;
        flagZ = value == 0;
        return value;
    }
    // Decimal arithmetic on two digits a byte: y + x or y - x, with X
    uint32_t Bcd(bool add, uint32_t x32, uint32_t y32) {
        const int x = static_cast<int>(x32 & 0xFF), y = static_cast<int>(y32 & 0xFF);
        int result;
        if (add) {
            const int low = (x & 15) + (y & 15) + flagX;
            result = x + y + flagX;
            if (low > 9) {
                result += 6;
            }
            flagC = flagX = result > 0x99;
            if (flagC) {
                result += 0x60;
            }
        } else {
            const int low = (y & 15) - (x & 15) - flagX;
            result = y - x - flagX;
            if (low < 0) {
                result -= 6;
            }
            flagC = flagX = result < 0;
            if (flagC) {
                result -= 0x60;
            }
        }
        flagZ = flagZ && (result & 0xFF) == 0;
        flagN = result & 0x80;
        return static_cast<uint32_t>(result) & 0xFF;
    }
    void Push32(uint32_t value) {
        a[7] -= 4;
        Write(a[7], 2, value);
    }
    uint32_t Pop32() {
        const uint32_t value = Read(a[7], 2);
        a[7] += 4;
        return value;
    }
    uint32_t Read(uint32_t address, unsigned size);
    void Write(uint32_t address, unsigned size, uint32_t value);
    uint32_t ReadProgram(uint32_t address, unsigned size);

    static constexpr uint32_t kMask[3] = {0xFF, 0xFFFF, 0xFFFFFFFF};
    static constexpr uint32_t kSign[3] = {0x80, 0x8000, 0x80000000};
    static constexpr uint32_t kBytes[3] = {1, 2, 4};

private:
    uint8_t m_interruptLevel = 0;
    uint32_t m_cycles = 0;  // of the instruction being run
    bool m_jumped = false;  // the instruction went somewhere the translator cannot follow

    struct Operand {
        enum class Kind : uint8_t { Data, Address, Memory, Program, Immediate } kind; // Program: memory, read as program
        uint32_t at; // register number, memory address or immediate value
    };
    uint16_t Fetch();
    uint32_t Fetch32();
    Operand Locate(unsigned mode, unsigned reg, unsigned size);
    uint32_t Load(const Operand &operand, unsigned size);
    void Store(const Operand &operand, unsigned size, uint32_t value);
    void Push16(uint16_t value);
    uint16_t Pop16();
    void Exception(unsigned vector, uint32_t returnAddress, int level);
    void Execute(uint16_t op);
    void Illegal(uint16_t op, uint32_t address);
    bool TakeInterrupt();

public:
    // For translated code: the instructions that have to do with exceptions and the status register, done as
    // the interpreter does them (the time they take is added by the caller)
    void Trap(unsigned number, uint32_t returnAddress) {
        pc = returnAddress;
        Exception(32 + number, returnAddress, -1);
    }
    void ReturnFromException() {
        const uint16_t sr = Pop16();
        pc = Pop32();
        SetSR(sr & 0xA71F);
    }
    void MoveToSR(uint16_t value) {
        SetSR(value & 0xA71F);
    }
    // For rewrites (runtime/lift.h): the game's code run on the spot, to the return of the routine the PC is
    // at (by the interpreter alone, hooks left out), or of the routine at `address` (as the game is run)
    // The registers kept and put back (for C++ that borrows the CPU to run a routine of the game's)
    struct Kept {
        uint32_t d[8], a[8];
        uint16_t sr;
    };
    Kept Keep() const {
        Kept kept;
        for (int n = 0; n < 8; n++) {
            kept.d[n] = d[n];
            kept.a[n] = a[n];
        }
        kept.sr = SR();
        return kept;
    }
    void PutBack(const Kept &kept) {
        SetSR(kept.sr);
        for (int n = 0; n < 8; n++) {
            d[n] = kept.d[n];
            a[n] = kept.a[n];
        }
    }
    void RunToReturn();
    void CallGuest(uint32_t address);

private:
    void Record(uint32_t address);
    void RunChecked(uint64_t until);
};

} // namespace cps2recomp
