// SPDX-License-Identifier: GPL-3.0-only
// Copyright (C) 2026 Tommy McLeroy. Part of recomp-common: https://github.com/tmcleroy/recomp-common
// The in-game menu shared by recomp ports (native ports of games made by static recompilation): save states
// (save, load, slot), the speed the game runs at, what the game itself offers (rows the host names, and its
// optional features and commands, a page for each of their categories), and leaving the game.
//
// It knows nothing of any game or system, and nothing of SDL. The host (a port's frontend) says what the
// rows are, opens it, stops the game while it is open, gives it the player's presses as the bits below and
// carries out what Buttons returns; the menu draws itself over a copy of the game's picture.
//
// C++17, no dependencies. C hosts use menu_c.h.
#pragma once

#include <cstddef>
#include <cstdint>
#include <functional>
#include <string>
#include <utility>
#include <vector>

namespace recomp {

// The menu's own buttons. The host turns its system's into these (several of the system's may be one).
enum : unsigned {
    kMenuUp = 1,
    kMenuDown = 2,
    kMenuLeft = 4,
    kMenuRight = 8,
    kMenuConfirm = 16, // chooses a row, changes it, goes into a page (as Right does)
    kMenuBack = 32,    // leaves a page for the one it was reached from; on the first page, closes the menu
};

// What the mouse did (Menu::Mouse), at a place in the picture the menu was last drawn over
enum class MenuMouse {
    Move,      // over a row: that row is chosen
    Click,     // the left button: on a row, chooses it and does what Confirm does there
    Back,      // the right button (anywhere): what Back does
    WheelUp,   // the wheel: the row above, as Up
    WheelDown, // the row below, as Down
};

// A row of the first page.
struct MenuRow {
    enum Kind {
        Save,   // "Save state": Buttons returns Chosen::Save
        Load,   // "Load state": Chosen::Load
        Slot,   // the slot (1 to MenuConfig::slots) those two use
        Speed,  // one of MenuConfig::speeds (left out when there are none)
        Pages,  // stands for several rows: the commands of no category, then a row for each category's page
        Page,   // a row for one page, named by `title`, wherever the host wants it; Pages then leaves it out
        Action, // the host's own: Chosen::Action with its id
        Quit,   // "Quit game": Chosen::Quit
        Resume, // closes the menu
        Mute,   // "Mute": off or on, through MenuConfig::muted and setMuted (left out without them)
        Reset,  // "Reset game": Chosen::Reset (the host starts the game again, as if switched off and on)
        ResetOptions, // "Reset all options": first asks "Are you sure?" (No, Yes; No chosen at first, Back is No);
                      // on Yes, the speed back to full, and Chosen::ResetOptions (the host puts every option back as
                      // it first was)
    };
    Kind kind;
    int id;                  // Action: handed back when chosen
    std::string title;       // Action; Page: the page's name
    std::string description; // Action; Reset, ResetOptions: in place of the menu's own words (what they leave as it is, say)
    MenuRow(Kind kind, int id = 0, std::string title = {}, std::string description = {})
        : kind(kind), id(id), title(std::move(title)), description(std::move(description)) {}
};

// An optional feature of the game: on or off, or a choice of several things.
struct MenuFeature {
    std::string category; // the page it is on
    std::string title;
    std::string description;
    // For a choice: the names, the first being the one that means off. Empty: on (1) or off (0).
    std::vector<std::string> choices = {};
    // A choice of many (stages, say) whose player keeps favourites (MenuConfig::favourite): Confirm on its row marks the
    // choice shown as one, or not (any of them: a list of stages may have none that means off), and a row under it goes
    // through the favourites alone
    bool favourites = false;
};

// Something the game can do when asked: Chosen::Command with its place in MenuConfig::commands.
struct MenuCommand {
    std::string category; // the page it is on ("": the first page, where the Pages row is)
    std::string title;
    std::string description;
};

// More about a page than its name, for the pages that need it. A page is a category of features and
// commands; one with a parent is reached from the parent's page, not from the first.
struct MenuPage {
    std::string name;        // the category
    std::string parent;      // the page its row is on ("": the first page)
    std::string description; // what its row says ("": "The page of <name> choices.")
    bool counts = true;      // its row says how many of its features are on
    // Speed and Mute rows at the top of this page, rather than on the first page (other kinds are left out here)
    std::vector<MenuRow::Kind> rows = {};
};

struct MenuConfig {
    // The first page, in groups; a line is drawn between groups.
    std::vector<std::vector<MenuRow>> groups;
    std::vector<MenuFeature> features;
    std::vector<MenuCommand> commands;
    // Pages that are under another page, or whose rows say something of their own. A page under another
    // comes on its parent's page after the parent's commands and before its features, in this order.
    std::vector<MenuPage> pages;
    // A feature's value now (by its place in `features`), and changing it
    std::function<int(size_t feature)> value;
    std::function<void(size_t feature, int value)> setValue;
    // Optional: whether the menu offers a choice of a feature (settings.h, MenuChoices): Left, Right and Confirm pass
    // over those it does not. Off (the first) and the one chosen now always are.
    std::function<bool(size_t feature, int choice)> offered;
    // Optional: a favourites feature's (MenuFeature::favourites) choices the player has marked, and marking one or not
    // (the host keeps them). Without these, such a feature is as any other.
    std::function<bool(size_t feature, int choice)> favourite;
    std::function<void(size_t feature, int choice, bool marked)> setFavourite;
    // The Speed row: the speeds' names, slowest first, and what the row's description says; full speed is the one
    // at normalSpeed (the slower ones before it, the faster after), the speed the menu starts at
    std::vector<std::string> speeds;
    int normalSpeed = 0;
    std::string speedDescription;
    // The Mute row: whether the game's sound is off now, and switching it off and on
    std::function<bool()> muted;
    std::function<void(bool muted)> setMuted;
    // What the menu's buttons are called on this system, for the hint line: kMenuConfirm ("a button",
    // "A, B or C") and what closes the menu ("Esc", "Esc or Select")
    std::string confirmName = "a button";
    std::string closeName = "Esc";
    // How many save-state slots the Slot row goes through (1 to slots, around)
    int slots = 9;
};

// Presses, with the arrows repeating while held, for a host that knows whether each button is down: given what is down
// each frame (kMenu... bits), what is pressed this frame: what has gone down since the last, and Up, Down, Left and
// Right again while held alone (after kRepeatAfter frames, then every kRepeatEvery; faster after kFasterAfter)
struct MenuRepeat {
    static constexpr int kRepeatAfter = 18, kRepeatEvery = 4, kFasterAfter = 60, kFasterEvery = 2;
    unsigned Step(unsigned held);
    unsigned m_held = 0; // (what was down at the last step, and for how many frames the arrows have been)
    int m_frames = 0;
};

class Menu {
public:
    struct Chosen {
        enum Kind { None, Save, Load, Quit, Action, Command, Reset, ResetOptions } kind = None;
        int id = 0; // Action: the row's id. Command: its place in MenuConfig::commands.
    };

    // What the menu shows. May be called again at any time (before each Open, say); the page and the row
    // the player was on are kept where they still exist.
    void Configure(MenuConfig config);
    void Open();
    void Close() {
        m_open = false;
    }
    bool IsOpen() const {
        return m_open;
    }
    // Buttons newly pressed (kMenu... bits; MenuRepeat makes them from those held): Up/Down choose, Confirm changes a row
    // or goes into a page (on a favourites feature's row, marks the choice shown a favourite or not),
    // Left/Right change a row with several values, Right on a page's row goes into that page, Left and Back
    // leave a page (for the one it was reached from), Back on the first page closes.
    // Returns what the host is to do (with Slot() for Save and Load); the host closes the menu if that
    // went well. Resume and Back close it themselves.
    Chosen Buttons(unsigned pressed);
    int Slot() const {
        return m_slot;
    }
    void SetSlot(int slot) { // 1 to MenuConfig::slots, around
        const int count = SlotCount();
        m_slot = ((slot - 1) % count + count) % count + 1;
    }
    int SlotCount() const {
        return m_config.slots > 0 ? m_config.slots : 9;
    }
    // The speed chosen, by its place in MenuConfig::speeds (MenuConfig::normalSpeed: full speed)
    int Speed() const {
        return m_speed;
    }
    void SetSpeed(int speed);
    // The mouse: where it is, in the pixels of the picture last given to Draw (the host maps the window's place to
    // that picture's), and what it did. Returns as Buttons does. A press away from the rows does nothing.
    Chosen Mouse(MenuMouse what, float x, float y);
    // A line to tell the player (why not, say), until the next press
    void Note(const std::string &text) {
        m_note = text;
    }
    // Over a picture of 32-bit pixels (red in the low byte)
    void Draw(uint32_t *pixels, int width, int height) const;
    // Compact: the rows in the small letters and close together, for a screen of few lines (an arcade monitor at its
    // 224 or 240): the page's rows all on it at once where they fit, and letters that never run into the next row's.
    // Off: the rows in letters twice as large (the usual)
    void SetCompact(bool compact) {
        m_compact = compact;
    }
    bool Compact() const {
        return m_compact;
    }

private:
    struct Row {
        int kind;
        size_t index;         // of the feature, the command or the first page's row
        std::string page;     // the page a row leads to
        bool divider = false; // a line above it: the first of a group of rows
    };
    void Fill();
    bool Favourites(size_t feature) const;
    const MenuPage *PageOf(const std::string &name) const;
    std::string Parent(const std::string &page) const;
    bool Exists(const std::string &page) const;
    void Enter(const std::string &page);
    void Leave();
    void EndConfirm();
    MenuConfig m_config;
    std::vector<MenuRow> m_first; // the first page's rows as given, groups one after another
    bool m_open = false;
    std::vector<Row> m_rows;
    std::string m_page;     // the category shown ("": the first page)
    int m_selected = 0;
    std::vector<int> m_left; // (the rows the pages above this one were left on, the first page's first)
    int m_speed = -1; // (-1: not chosen yet, so full speed)
    int m_slot = 1;
    std::string m_note;
    // (where Draw last put each row shown, for Mouse: the row, and its top and bottom; and the panel's left and right)
    struct Shown {
        int row;
        float top, bottom;
    };
    mutable std::vector<Shown> m_shown;
    mutable float m_panelLeft = 0, m_panelRight = 0;
    // (Reset all options asked about: the page of No and Yes is shown in place of the one it was chosen on, and the row
    // it was on, to go back to)
    bool m_confirm = false;
    size_t m_confirmIndex = 0;
    int m_confirmFrom = 0;
    bool m_compact = false;
};

} // namespace recomp
