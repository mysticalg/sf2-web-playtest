// Private browser bridge for original EU static translations; no CE adapter.
#include "machine.h"
#include "game.h"
#ifdef SSF_PUBLIC
#include "cps2crypt.h"
#endif
#include <emscripten/emscripten.h>
#include <fstream>
#include <memory>
using namespace cps2recomp;
namespace cps2recomp{bool MakeGfxTable(const Board&b,GfxTable&t){if(b.cps1)abort();t=GfxTable();return true;}}
namespace{RomSet rom;std::unique_ptr<Machine> machine;int32_t state[40];std::vector<uint8_t>load(const char*p){std::ifstream f(p,std::ios::binary);if(!f)abort();return{std::istreambuf_iterator<char>(f),{}};}}
extern "C"{
EMSCRIPTEN_KEEPALIVE int ssf_init(){
#ifndef SSF_PUBLIC
if(rom.program.empty()){rom.program=load("/rom/program.bin.data");rom.opcodes=load("/rom/program.bin");rom.graphics=load("/rom/graphics.bin");rom.soundProgram=load("/rom/program.bin.z80");rom.samples=load("/rom/samples.bin");}
#endif
if(rom.program.size()!=0x400000||rom.graphics.size()!=0x1000000||rom.soundProgram.size()!=0x40000||rom.samples.size()!=0x400000)return 0;machine=std::make_unique<Machine>(rom);SetRam(machine->ram.data(),machine->videoRam.data());SetProgram(rom.program.data(),uint32_t(rom.program.size()));SetProgramOpcodes(rom.opcodes.data());machine->cpuMode=M68K::Mode::Native;machine->soundMode=Z80::Mode::Native;machine->SetBoardTiming(true);machine->Reset();return 1;}
#ifdef SSF_PUBLIC
EMSCRIPTEN_KEEPALIVE int ssf_load(const uint8_t*program,const uint8_t*graphics,const uint8_t*sound,const uint8_t*samples){
rom.program.assign(program,program+0x400000);rom.graphics.assign(graphics,graphics+0x1000000);rom.soundProgram.assign(sound,sound+0x40000);rom.samples.assign(samples,samples+0x400000);std::vector<uint16_t>in(0x200000),out(0x200000);for(size_t n=0;n<in.size();n++)in[n]=uint16_t((rom.program[n*2]<<8)|rom.program[n*2+1]);const uint32_t historicalEuroMaster[2]={0x944e8302,0x56d3143c};DecryptProgram(in.data(),out.data(),out.size(),historicalEuroMaster,0,0x200000);rom.opcodes.resize(0x400000);for(size_t n=0;n<out.size();n++){rom.opcodes[n*2]=uint8_t(out[n]>>8);rom.opcodes[n*2+1]=uint8_t(out[n]);}return ssf_init();}
EMSCRIPTEN_KEEPALIVE const uint8_t*ssf_rom_ptr(int part){switch(part){case 0:return rom.program.data();case 1:return rom.opcodes.data();case 2:return rom.graphics.data();case 3:return rom.soundProgram.data();case 4:return rom.samples.data();default:return nullptr;}}
#endif
EMSCRIPTEN_KEEPALIVE int ssf_setting(int kind,int value){if(!machine)return 0;if(kind==0&&value>=0&&value<=7){machine->Write8(0xff82d3,uint8_t(value));return 1;}if(kind==1&&value>=0&&value<=4){machine->Write8(0xff83a9,uint8_t(value));return 1;}return 0;}
EMSCRIPTEN_KEEPALIVE int ssf_tick(int p1,int p2){if(!machine)return 0;machine->audio.clear();machine->players[0]=uint16_t(p1);machine->players[1]=uint16_t(p2);machine->RunFrame();return int(machine->frame);}
EMSCRIPTEN_KEEPALIVE void ssf_drawing(int on){if(machine)machine->drawing=on!=0;}
EMSCRIPTEN_KEEPALIVE uint32_t*ssf_pixels(){return machine?machine->Picture():nullptr;}
EMSCRIPTEN_KEEPALIVE int ssf_width(){return machine?machine->PictureWidth():384;}
EMSCRIPTEN_KEEPALIVE int16_t*ssf_audio(){return machine&&!machine->audio.empty()?machine->audio.data():nullptr;}
EMSCRIPTEN_KEEPALIVE int ssf_audio_count(){return machine?int(machine->audio.size()):0;}
EMSCRIPTEN_KEEPALIVE int ssf_read(int address,int size){if(!machine)return 0;return size==1?machine->Read8(address):machine->Read16(address);}
EMSCRIPTEN_KEEPALIVE int32_t*ssf_state(){if(!machine)return nullptr;auto&m=*machine;state[0]=int(m.frame);state[1]=int(m.cpu.pc);state[2]=m.Read16(0xff8000);state[3]=m.Read16(0xff8004);state[4]=m.Read16(0xff8008);state[5]=m.Read16(0xff8c4e);state[6]=m.Read8(0xff82e9);state[7]=m.Read8(0xff82f0);state[8]=int16_t(m.Read16(0xff8478));state[9]=int16_t(m.Read16(0xff8878));state[10]=m.Read8(0xff87df);state[11]=m.Read8(0xff8bdf);state[12]=m.Read16(0xff8454);state[13]=m.Read16(0xff8854);state[14]=int16_t(m.Read16(0xff8458));state[15]=int16_t(m.Read16(0xff8858));state[16]=m.Read8(0xff8451);state[17]=m.Read8(0xff8851);state[18]=m.Read8(0xff8804);state[19]=m.Read8(0xff8c04);state[20]=m.Read8(0xff880b);state[21]=m.Read8(0xff8c0b);state[22]=m.Read8(0xff880b);state[23]=m.Read16(0xff8702);state[24]=int(m.cpu.interpreted);state[25]=int(m.soundCpu.interpreted);state[26]=m.soundCpu.pc;state[27]=m.Read8(0xff87ff);state[28]=m.Read8(0xff8bff);return state;}
}
int main(){return 0;}
